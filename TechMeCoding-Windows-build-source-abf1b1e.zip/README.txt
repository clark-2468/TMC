TechMeCoding Windows x64 source handoff
=====================================

The Git bundle contains the development commits since the original TMC
lesson importer. Use the bundle with a Git clone of clark-2468/TMC.

1. Extract this ZIP.
2. Open x64 Developer PowerShell for Visual Studio. Install the supported
   C++ toolchain and Windows SDK, and verify signtool.exe is on PATH.
3. Run these commands, replacing C:\path\to with the extracted folder:

   git clone https://github.com/clark-2468/TMC.git
   cd TMC
   git fetch "C:\path\to\tmc-development.bundle" refs/heads/tmc-development:refs/heads/tmc-local-build
   git switch tmc-local-build
   git rev-parse HEAD

   Use Node.js 24.22.1 (or a newer 24.x version) and pnpm 12.16.0.

   pnpm install --frozen-lockfile
   pnpm run gulp vscode-win32-x64

The VSCode-win32-x64 folder appears beside the checkout. Launch
TechMeCoding.exe from that folder with the other packaged files in place.
See WINDOWS-BUILD.md for the desktop smoke test.

Pinned source revision:
abf1b1e4428becd85e990e3843938bcd0434295a
